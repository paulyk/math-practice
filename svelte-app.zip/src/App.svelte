<script>	
	import Nested from './Nested.svelte';
	import NTimesForm from './NTimesForm.svelte'
	import Problems from './Problems.svelte';
	import {gen_n_times_set } from './generator.js'

	  let options = {
			n: 2,
			from: 2,
			to: 12,
			count: 10
		}
		
		let questions = []
		
		function ongenerate() {
			questions = gen_n_times_set(options)
		}
</script>

<header>Hello</header>
<NTimesForm bind:options={options} />
<button on:click|preventDefault={ongenerate}>
	Generate
</button>
<Problems questions={questions} />





