export function gen_n_times_set(options) {
	let {n, from , to, count} = options
	let expressons = []
	let i = from
	let j = 0
	while (j < count) {
		expressons.push(`${n} * ${i}`)
		i++
		if (i > to) {
			i = from
		}
		j++
	}
	
	return expressons.map(expression =>({ expression, done: false }))
}